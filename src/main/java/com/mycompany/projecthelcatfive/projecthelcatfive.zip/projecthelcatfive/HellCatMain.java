/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projecthelcatfive;

/**
 *
 * @author alpah
 */
public class HellCatMain {
    
    public static void main (String [] args)
    {
       MainTab mn = new MainTab();
       mn.setVisible(true);
       
    }
    
}
